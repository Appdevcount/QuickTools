# Building the Clean-Architecture Azure Template — Manual Walkthrough

This guide is written so you (or anyone on the team) can build the whole thing **by hand**, understand every moving part, and demo it live. It has six parts:

- **Part A** — Build the reference solution manually (the thing the template will generate).
- **Part B** — Convert that solution into a `dotnet new` template (renaming, toggles, and value parameters).
- **Part C** — Test the template locally.
- **Part D** — Pack it as a NuGet package and publish to your internal feed.
- **Part E** — How the team consumes it day-to-day (CLI).
- **Part F** — Using the template in **Visual Studio** (consuming and authoring).

Three appendices cover the **naming convention**, **troubleshooting**, and **the full list of creation parameters**.

> **The big idea:** a `dotnet new` template is just a normal, working solution plus one metadata file (`.template.config/template.json`). You build a solution you're happy with, then add metadata that tells the engine *what to rename*, *what to make optional*, and *which values to prompt for*. That's the whole trick.

---

## Prerequisites

- **.NET 10 SDK (10.0.100+)** — `dotnet --version` should print `10.x`.
- An IDE (Visual Studio 2026 / Rider / VS Code).
- For running the generated service against real Azure: the **Azure CLI** (`az login`). Not needed just to build the template.

Conventions:
- The placeholder name during authoring is **`Company.Service`**. The engine swaps it for whatever the user passes to `-n` (e.g. `Contoso.Orders`).
- Run all commands from the repo root unless stated otherwise.

---

## Part A — Build the reference solution by hand

Five projects. Dependencies point **inward**.

```
Api ----+
        +--> Infrastructure --> Application --> Domain
Worker -+
```

| Project | Role | Allowed references |
|---|---|---|
| `Company.Service.Domain` | Entities, value objects, domain events. Pure C#. | -- |
| `Company.Service.Application` | Use-cases + ports (interfaces) + DTOs. | Domain |
| `Company.Service.Infrastructure` | Azure SDK implementations of the ports. | Application, Domain |
| `Company.Service.Api` | HTTP host, endpoints, composition root. | Application, Infrastructure |
| `Company.Service.Worker` | Background host, Service Bus consumer, composition root. | Application, Infrastructure |

### A.1 Create the folder and solution

```bash
mkdir Company.Service && cd Company.Service
dotnet new sln -n Company.Service
```

### A.2 Add the solution-wide standards files

`global.json` pins the SDK; `Directory.Build.props` shares MSBuild settings; `Directory.Packages.props` enables **Central Package Management** (every NuGet version in one place, projects reference packages with no version). All three sit at the repo root and apply to every project automatically. (Full contents are in this repo.)

> Verify package versions before committing: `dotnet list package --outdated`.

### A.3 Create the five projects

```bash
dotnet new classlib -n Company.Service.Domain         -o src/Company.Service.Domain
dotnet new classlib -n Company.Service.Application    -o src/Company.Service.Application
dotnet new classlib -n Company.Service.Infrastructure -o src/Company.Service.Infrastructure
dotnet new webapi   -n Company.Service.Api            -o src/Company.Service.Api
dotnet new worker   -n Company.Service.Worker         -o src/Company.Service.Worker
```

Delete the throwaway `Class1.cs` files.

### A.4 Wire project references (enforces the dependency rule)

```bash
dotnet add src/Company.Service.Application    reference src/Company.Service.Domain
dotnet add src/Company.Service.Infrastructure reference src/Company.Service.Application
dotnet add src/Company.Service.Api            reference src/Company.Service.Application src/Company.Service.Infrastructure
dotnet add src/Company.Service.Worker         reference src/Company.Service.Application src/Company.Service.Infrastructure
```

The compiler now physically prevents Domain from referencing Infrastructure — the architecture rule is enforced by the build.

### A.5 Add the projects to the solution

```bash
dotnet sln Company.Service.sln add src/Company.Service.Domain/Company.Service.Domain.csproj \
  src/Company.Service.Application/Company.Service.Application.csproj \
  src/Company.Service.Infrastructure/Company.Service.Infrastructure.csproj \
  src/Company.Service.Api/Company.Service.Api.csproj \
  src/Company.Service.Worker/Company.Service.Worker.csproj
```

### A.6 Add NuGet packages (versions come from Central Package Management)

```bash
cd src/Company.Service.Infrastructure
dotnet add package Azure.Identity
dotnet add package Microsoft.Azure.Cosmos
dotnet add package Azure.Messaging.ServiceBus
dotnet add package Azure.Storage.Blobs
dotnet add package Azure.Extensions.AspNetCore.Configuration.Secrets
dotnet add package Azure.Monitor.OpenTelemetry.AspNetCore
dotnet add package OpenTelemetry.Extensions.Hosting
cd ../../
dotnet add src/Company.Service.Api package Microsoft.AspNetCore.OpenApi
dotnet add src/Company.Service.Worker package Azure.Messaging.ServiceBus
```

### A.7 Write the code, layer by layer

Copy the files from `templates/cleanarch-azure/src/...` — they are the finished reference implementation. Highlights:

- **Domain** — `BaseEntity`, `IDomainEvent`, the `Order` aggregate (factory + invariants), `OrderCreatedEvent`.
- **Application** — ports (`IOrderRepository`, `IMessagePublisher`, `IBlobStorageService`), DTOs, `OrderService`, and `AddApplication()`.
- **Infrastructure** — `AzureOptions`, Cosmos/Service Bus/Blob implementations, telemetry + Key Vault extensions, and `AddInfrastructure()` which registers every Azure client with one `DefaultAzureCredential` (no secrets in code).
- **Api** — `Program.cs` composition root + minimal-API `OrderEndpoints`.
- **Worker** — `Program.cs` + `OrderMessageConsumer` (a `BackgroundService` over `ServiceBusProcessor`).

### A.8 Build and run

```bash
dotnet build
dotnet run --project src/Company.Service.Api      # browse /openapi/v1.json
dotnet run --project src/Company.Service.Worker   # starts the queue processor
```

### A.9 (Optional) Migrate to the modern `.slnx` solution format

```bash
dotnet sln Company.Service.sln migrate   # produces Company.Service.slnx
rm Company.Service.sln
```

You now have a clean, working reference solution. **That is what the template reproduces.**

---

## Part B — Turn the solution into a `dotnet new` template

A template = your solution + a `.template.config/template.json` manifest. You decide three things: what gets **renamed**, what's **optional**, and which **values to prompt for**.

### B.1 The renaming trick (`sourceName`)

The engine replaces **every occurrence** of `sourceName` — in file contents, file names and folder names — with the value passed to `-n`. Our placeholder is `Company.Service`, so:

```bash
dotnet new cleanarch-azure -n Contoso.Orders
```

turns `Company.Service.Domain` into `Contoso.Orders.Domain`, etc. This is exactly why the convention is `{Company}.{Service}.{Layer}`: the user supplies `{Company}.{Service}` as one name and the fixed `.{Layer}` suffixes come along automatically. **One parameter, perfectly consistent naming.**

### B.2 Create the manifest

`.template.config/template.json` declares the `sourceName`, the `symbols` (parameters), and `sources.modifiers` (conditional files). The full manifest is in this repo; the sections below explain each mechanism.

### B.3 Strip the toggled-off code, not just the files

Excluding a file with a modifier isn't enough — code that *references* it must also disappear or the project won't compile. Use the engine's C# preprocessor support, evaluated at generation time:

```csharp
#if (UseCosmos)
        services.AddSingleton(sp => /* CosmosClient ... */);
        services.AddScoped<IOrderRepository, CosmosOrderRepository>();
#endif
```

…and in `.csproj`, the XML-comment form:

```xml
<!--#if (UseServiceBus) -->
<PackageReference Include="Azure.Messaging.ServiceBus" />
<!--#endif -->
```

**Rule:** if a file is excluded by a modifier, every line that uses it must sit inside a matching `#if`.

### B.5 Expose hard-coded values as creation-time parameters

Toggles aren't enough — teams also want to set the entity name, the Azure endpoints, queue/database names and ports **at creation time**. Three mechanisms cover every case.

**1. `replaces` — substitute a literal everywhere.** A `string` parameter swaps its `replaces` literal in all file contents. Pick literals that are unique:

```json
"CosmosDatabase":      { "type": "parameter", "datatype": "string", "defaultValue": "appdb", "replaces": "appdb" },
"ServiceBusNamespace": { "type": "parameter", "datatype": "string", "defaultValue": "your-namespace.servicebus.windows.net", "replaces": "your-namespace.servicebus.windows.net" },
"HttpsPort":           { "type": "parameter", "datatype": "string", "defaultValue": "7081", "replaces": "7081" }
```

**2. Empty defaults need a token.** You can't `replaces: ""`. For optional secrets put a unique placeholder token in `appsettings.json` and replace that:

```jsonc
"KeyVault":            { "Uri": "KEYVAULT_URI" },
"ApplicationInsights": { "ConnectionString": "APPINSIGHTS_CONNECTION_STRING" }
```
```json
"KeyVaultUri":                 { "type": "parameter", "datatype": "string", "defaultValue": "", "replaces": "KEYVAULT_URI" },
"AppInsightsConnectionString": { "type": "parameter", "datatype": "string", "defaultValue": "", "replaces": "APPINSIGHTS_CONNECTION_STRING" }
```

**3. `fileRename` + a generated lower-case symbol — rename the sample entity.** `replaces` only touches file *contents*; `fileRename` also renames files and folders. A `generated` casing symbol produces the lower-case form used in routes and default container/queue names:

```json
"EntityName":      { "type": "parameter", "datatype": "string", "defaultValue": "Order", "replaces": "Order", "fileRename": "Order" },
"entityNameLower": { "type": "generated", "generator": "casing", "parameters": { "source": "EntityName", "toLower": true }, "replaces": "order" }
```

Now `--EntityName Invoice` renames `Order`→`Invoice`, `OrderService`→`InvoiceService`, `IOrderRepository`→`IInvoiceRepository`, the `Orders/` folder, and the `/orders` route → `/invoices`. The two replaces are case-sensitive, so `Order` and `order` never collide.

> **Rule:** give each configurable value a **unique literal** in the source (`appdb`, `7081`, full endpoint URIs, and the `KEYVAULT_URI` / `SERVICEBUS_QUEUE` / `COSMOS_CONTAINER` tokens are all distinct), so no parameter accidentally rewrites another's text. The complete list is in **Appendix 3**.

### B.6 Optional scaffolding (Tests, Docker, CI)

`bool` and `choice` symbols plus modifiers add or drop whole sub-trees:

```json
"IncludeTests":  { "type": "parameter", "datatype": "bool",   "defaultValue": "true" },
"IncludeDocker": { "type": "parameter", "datatype": "bool",   "defaultValue": "false" },
"IncludeCI":     { "type": "parameter", "datatype": "bool",   "defaultValue": "false" },
"CIProvider":    { "type": "parameter", "datatype": "choice", "defaultValue": "github",
                   "choices": [ { "choice": "github" }, { "choice": "azuredevops" } ] }
```
```json
"modifiers": [
  { "condition": "(!IncludeTests)",  "exclude": [ "tests/**" ] },
  { "condition": "(!IncludeDocker)", "exclude": [ "src/Company.Service.Api/Dockerfile", "src/Company.Service.Worker/Dockerfile", ".dockerignore" ] },
  { "condition": "(!IncludeCI || CIProvider != \"github\")",      "exclude": [ ".github/**" ] },
  { "condition": "(!IncludeCI || CIProvider != \"azuredevops\")", "exclude": [ "azure-pipelines.yml" ] }
]
```

Because the test project, Dockerfiles and pipeline files don't feed the main build, excluding them never breaks compilation. The `.slnx` reference to the test project and the test package versions in `Directory.Packages.props` are themselves wrapped in `<!--#if (IncludeTests) -->`.

### B.4 Folder layout recap

```
templates/cleanarch-azure/
├── .template.config/
│   ├── template.json        # manifest: sourceName, symbols, modifiers
│   └── ide.host.json        # Visual Studio labels for each symbol
├── global.json
├── Directory.Build.props
├── Directory.Packages.props
├── Company.Service.slnx
├── .dockerignore            # (IncludeDocker)
├── azure-pipelines.yml      # (IncludeCI + CIProvider=azuredevops)
├── .github/workflows/ci.yml # (IncludeCI + CIProvider=github)
├── src/
│   ├── Company.Service.Domain/
│   ├── Company.Service.Application/
│   ├── Company.Service.Infrastructure/
│   ├── Company.Service.Api/        (+ Dockerfile when IncludeDocker)
│   └── Company.Service.Worker/     (+ Dockerfile when IncludeDocker)
└── tests/
    └── Company.Service.UnitTests/  (IncludeTests)
```

---

## Part C — Test the template locally

Install straight from the folder — no NuGet pack needed.

```bash
dotnet new install ./templates/cleanarch-azure
dotnet new list cleanarch-azure
```

Generate and verify:

```bash
mkdir /tmp/demo && cd /tmp/demo
dotnet new cleanarch-azure -n Contoso.Orders -o Contoso.Orders
dotnet build Contoso.Orders

# A fully customised, lean variant
dotnet new cleanarch-azure -n Contoso.Billing -o Contoso.Billing \
  --EntityName Invoice --UseBlobStorage false --UseServiceBus false --IncludeTests true
dotnet build Contoso.Billing
```

Iterating? Reinstall after each change: `dotnet new install ./templates/cleanarch-azure --force`. Uninstall with `dotnet new uninstall ./templates/cleanarch-azure`.

> **Demo tip:** generate the full service and a toggled-down one side by side and `diff` the two `src` trees.

---

## Part D — Pack as NuGet and publish to your internal feed

```bash
dotnet pack -c Release          # -> bin/Release/YourCompany.CleanArch.Templates.1.0.0.nupkg
dotnet new install ./bin/Release/YourCompany.CleanArch.Templates.1.0.0.nupkg   # smoke test
```

Publish (Azure DevOps Artifacts shown; swap source/api-key for GitHub Packages or nuget.org):

```bash
dotnet nuget push bin/Release/YourCompany.CleanArch.Templates.1.0.0.nupkg \
  --source "https://pkgs.dev.azure.com/<org>/_packaging/<feed>/nuget/v3/index.json" --api-key az
```

Bump `<Version>` in `templatepack.csproj` each release and wire `dotnet pack` + `dotnet nuget push` into CI.

---

## Part E — How the team consumes it

```bash
dotnet new install YourCompany.CleanArch.Templates          # one-time, from the feed
dotnet new cleanarch-azure -n Contoso.Inventory -o Contoso.Inventory
dotnet new cleanarch-azure -n Contoso.Catalog --UseServiceBus false   # toggles
dotnet new update                                           # pull newer template releases
```

---

## Part F — Using the template in Visual Studio

The Visual Studio "New Project" dialog reads the **same** template engine as the CLI, so anything installed with `dotnet new install` appears in VS automatically.

> Use Visual Studio 2026 (or 2022 17.8+) with the **.NET 10 SDK** selected.

### F.1 Consume the template (create a new service)

1. Install once (CLI — there is no GUI installer for templates):
   ```bash
   dotnet new install YourCompany.CleanArch.Templates       # from the feed
   # or during development:
   dotnet new install .\templates\cleanarch-azure
   ```
2. **Restart Visual Studio** if it was open — VS scans templates at startup.
3. **File → New → Project**, search **`cleanarch-azure`**, select it → **Next**.
4. **Project name** is the `-n` value — enter `{Company}.{Service}`, e.g. `Contoso.Orders`.
5. On **Additional information** you'll see every parameter: text boxes for the entity name, endpoints, ports, etc., and checkboxes for the Azure toggles and Tests/Docker/CI. Fill them in → **Create**.
6. To run, set **multiple startup projects** (solution → *Configure Startup Projects*), start both `*.Api` and `*.Worker`, press **F5**.

### F.2 Make the wizard read nicely — `ide.host.json`

By default the dialog shows raw symbol names (`UseServiceBus`). The optional `.template.config/ide.host.json` (already in this repo) maps every symbol to a friendly label and order, e.g. *“Include Azure Service Bus (messaging + Worker)”* and *“Sample entity name (e.g. Order, Invoice)”*. Add a 32×32 `icon.png` next to it for a gallery tile. After editing it, run `dotnet new install … --force` and restart VS.

### F.3 Author and test the template inside Visual Studio

- **Edit** `templates/cleanarch-azure/Company.Service.slnx` like any normal solution — IntelliSense and build work because it *is* a real solution.
- **Reinstall** after each change from the integrated terminal: `dotnet new install <folder> --force`, then File → New → Project to see the result. There's no live-reload for templates.
- **Pack**: right-click `templatepack.csproj` → **Pack** (= `dotnet pack -c Release`).
- **Publish**: from the terminal with `dotnet nuget push` (no GUI push for template packages).

### F.4 Visual Studio gotchas

| Symptom | Fix |
|---|---|
| Template doesn't appear | Not installed, or VS not restarted after install. |
| Checkboxes show raw `UseServiceBus` | Add/repair `ide.host.json`, reinstall with `--force`, restart VS. |
| `net10.0` not recognised | Select the .NET 10 SDK (Tools → Options → Environment → Preview Features) and pin it in `global.json`. |
| Generated solution won't build | A toggled-off feature left an un-`#if`'d reference. See Appendix 2. |
| VS still generates the old template | Forgot `--force`, or edited the generated copy instead of the template source. |

---

## Appendix 1 — Naming convention

**`{Company}.{Service}.{Layer}`**, e.g. `Contoso.Orders.Api`.

`{Company}.{Service}` is the single value passed to `-n`; it becomes the assembly prefix, root namespace prefix and `src/` folder prefix. `{Layer}` is one of the fixed suffixes: `.Domain`, `.Application`, `.Infrastructure`, `.Api`, `.Worker`. Because the suffixes are baked into the template, every generated service is named identically — namespaces match folder paths match assembly names, with no drift.

## Appendix 2 — Troubleshooting

| Symptom | Cause / Fix |
|---|---|
| `dotnet new cleanarch-azure` not found | Template not installed, or you pointed `install` at the wrong folder. Install the folder that *contains* `.template.config`. |
| Generated project won't compile after toggling a feature off | A `using`/registration line referencing the excluded file wasn't wrapped in `#if`. Wrap it. |
| `#if` lines appear verbatim in output | Symbol name typo, or the condition spelling doesn't match a declared symbol. |
| One stray `Company.Service` not renamed | That text didn't match the `sourceName` literal exactly. |
| Two values change together unexpectedly | Their source literals overlap. Give each a unique literal/token (Appendix 3). |
| CPM error `NU1008` | With Central Package Management, never put `Version=` on `<PackageReference>`; versions live only in `Directory.Packages.props`. |
| Azure client auth errors locally | Run `az login`. `DefaultAzureCredential` uses your CLI/IDE identity locally and Managed Identity in Azure. |

## Appendix 3 — All creation parameters

Everything below is promptable in `dotnet new` (as `--Name value`) and as a field/checkbox in the Visual Studio wizard.

| Parameter | Type | Default | Configures |
|---|---|---|---|
| *(name)* `-n` | string | — | `{Company}.{Service}` prefix for every project, namespace and folder. |
| `EntityName` | string | `Order` | Sample aggregate + all derived class names, files, and the `/orders` route. |
| `CosmosAccountEndpoint` | string | `https://localhost:8081` | Cosmos DB account endpoint. |
| `CosmosDatabase` | string | `appdb` | Cosmos DB database name. |
| `CosmosContainer` | string | `orders` | Cosmos DB container name. |
| `ServiceBusNamespace` | string | `your-namespace.servicebus.windows.net` | Service Bus FQDN. |
| `ServiceBusQueue` | string | `orders` | Queue the API publishes to / Worker consumes. |
| `BlobServiceUri` | string | `https://yourstorage.blob.core.windows.net` | Blob Storage service URI. |
| `KeyVaultUri` | string | *(blank)* | Key Vault URI; blank disables the KV config source at runtime. |
| `AppInsightsConnectionString` | string | *(blank)* | App Insights connection string. |
| `HttpsPort` | string | `7081` | Local HTTPS port. |
| `HttpPort` | string | `5081` | Local HTTP port. |
| `UseCosmos` | bool | `true` | Include Cosmos persistence. |
| `UseServiceBus` | bool | `true` | Include Service Bus + Worker consumer. |
| `UseBlobStorage` | bool | `true` | Include Blob Storage. |
| `UseKeyVault` | bool | `true` | Layer Key Vault into configuration. |
| `UseTelemetry` | bool | `true` | Wire App Insights via OpenTelemetry. |
| `IncludeTests` | bool | `true` | Add the xUnit unit-test project. |
| `IncludeDocker` | bool | `false` | Add Dockerfiles for API + Worker. |
| `IncludeCI` | bool | `false` | Add a CI pipeline. |
| `CIProvider` | choice | `github` | `github` or `azuredevops` (used when `IncludeCI` is true). |

**Example — fully customised, lean service:**

```bash
dotnet new cleanarch-azure -n Contoso.Billing -o Contoso.Billing \
  --EntityName Invoice \
  --CosmosDatabase billing --CosmosContainer invoices \
  --ServiceBusNamespace contoso-prod.servicebus.windows.net --ServiceBusQueue invoice-events \
  --KeyVaultUri https://contoso-kv.vault.azure.net/ \
  --HttpsPort 7443 --HttpPort 5443 \
  --UseBlobStorage false \
  --IncludeDocker true --IncludeCI true --CIProvider azuredevops
```

---

### Command cheat-sheet

```bash
dotnet new install ./templates/cleanarch-azure          # install from folder
dotnet new install ./templates/cleanarch-azure --force  # reinstall after edits
dotnet new list cleanarch-azure                         # confirm registration
dotnet new cleanarch-azure -n Contoso.Orders -o Contoso.Orders        # generate (defaults)
dotnet new cleanarch-azure -n X --EntityName Invoice --UseServiceBus false   # generate, customised
dotnet new uninstall ./templates/cleanarch-azure        # uninstall
dotnet pack -c Release                                  # build the nupkg
dotnet nuget push <nupkg> --source <feed> --api-key <k> # publish
```
