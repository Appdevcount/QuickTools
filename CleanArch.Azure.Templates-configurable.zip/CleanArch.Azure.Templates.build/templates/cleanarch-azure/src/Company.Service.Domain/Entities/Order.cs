using Company.Service.Domain.Common;
using Company.Service.Domain.Events;

namespace Company.Service.Domain.Entities;

/// <summary>Sample aggregate root. Replace with your real domain model.</summary>
public sealed class Order : BaseEntity
{
    public string CustomerName { get; private set; }
    public decimal Amount { get; private set; }
    public OrderStatus Status { get; private set; }
    public DateTimeOffset CreatedOnUtc { get; private set; }

    private Order(string customerName, decimal amount)
    {
        CustomerName = customerName;
        Amount = amount;
        Status = OrderStatus.Pending;
        CreatedOnUtc = DateTimeOffset.UtcNow;
    }

    public static Order Create(string customerName, decimal amount)
    {
        if (string.IsNullOrWhiteSpace(customerName))
            throw new ArgumentException("Customer name is required.", nameof(customerName));
        if (amount <= 0)
            throw new ArgumentOutOfRangeException(nameof(amount), "Amount must be positive.");

        var order = new Order(customerName, amount);
        order.RaiseDomainEvent(new OrderCreatedEvent(order.Id, order.Amount));
        return order;
    }

    public void MarkProcessed() => Status = OrderStatus.Processed;
}

public enum OrderStatus
{
    Pending = 0,
    Processed = 1,
    Cancelled = 2
}
