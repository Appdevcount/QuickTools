namespace Company.Service.Domain.Common;

/// <summary>Marker for domain events raised by entities.</summary>
public interface IDomainEvent
{
    DateTimeOffset OccurredOnUtc { get; }
}
