using Company.Service.Domain.Common;

namespace Company.Service.Domain.Events;

public sealed record OrderCreatedEvent(Guid OrderId, decimal Amount) : IDomainEvent
{
    public DateTimeOffset OccurredOnUtc { get; } = DateTimeOffset.UtcNow;
}
