using Company.Service.Application.Orders;
using Microsoft.Extensions.DependencyInjection;

namespace Company.Service.Application;

public static class DependencyInjection
{
    /// <summary>Registers application use-case services. Called by both Api and Worker.</summary>
    public static IServiceCollection AddApplication(this IServiceCollection services)
    {
        services.AddScoped<IOrderService, OrderService>();
        return services;
    }
}
