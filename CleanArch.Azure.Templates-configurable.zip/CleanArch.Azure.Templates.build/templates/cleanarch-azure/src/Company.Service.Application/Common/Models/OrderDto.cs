namespace Company.Service.Application.Common.Models;

public sealed record CreateOrderRequest(string CustomerName, decimal Amount);

public sealed record OrderDto(Guid Id, string CustomerName, decimal Amount, string Status);
