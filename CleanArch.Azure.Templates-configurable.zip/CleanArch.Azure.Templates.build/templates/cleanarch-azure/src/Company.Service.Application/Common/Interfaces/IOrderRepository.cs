using Company.Service.Domain.Entities;

namespace Company.Service.Application.Common.Interfaces;

/// <summary>Persistence port. Implemented in Infrastructure (Cosmos DB).</summary>
public interface IOrderRepository
{
    Task<Order?> GetByIdAsync(Guid id, CancellationToken ct = default);
    Task AddAsync(Order order, CancellationToken ct = default);
    Task UpdateAsync(Order order, CancellationToken ct = default);
}
