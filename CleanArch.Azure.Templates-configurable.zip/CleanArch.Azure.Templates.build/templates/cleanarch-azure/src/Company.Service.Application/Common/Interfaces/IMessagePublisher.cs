namespace Company.Service.Application.Common.Interfaces;

/// <summary>Outbound messaging port. Implemented in Infrastructure (Service Bus).</summary>
public interface IMessagePublisher
{
    Task PublishAsync<T>(T message, CancellationToken ct = default) where T : class;
}
