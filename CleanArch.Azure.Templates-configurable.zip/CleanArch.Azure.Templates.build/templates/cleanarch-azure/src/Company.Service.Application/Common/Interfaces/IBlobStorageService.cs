namespace Company.Service.Application.Common.Interfaces;

/// <summary>Blob storage port. Implemented in Infrastructure (Azure Blob Storage).</summary>
public interface IBlobStorageService
{
    Task<Uri> UploadAsync(string container, string blobName, Stream content, CancellationToken ct = default);
    Task<Stream?> DownloadAsync(string container, string blobName, CancellationToken ct = default);
}
