using Company.Service.Application.Common.Interfaces;
using Company.Service.Application.Common.Models;
using Company.Service.Domain.Entities;
using Company.Service.Domain.Events;
using Microsoft.Extensions.Logging;

namespace Company.Service.Application.Orders;

internal sealed class OrderService(
    IOrderRepository repository,
#if (UseServiceBus)
    IMessagePublisher publisher,
#endif
    ILogger<OrderService> logger) : IOrderService
{
    public async Task<OrderDto> CreateOrderAsync(CreateOrderRequest request, CancellationToken ct = default)
    {
        var order = Order.Create(request.CustomerName, request.Amount);
        await repository.AddAsync(order, ct);

#if (UseServiceBus)
        // Publish integration event so the background Worker (or other services) can react.
        await publisher.PublishAsync(new OrderCreatedEvent(order.Id, order.Amount), ct);
#endif
        order.ClearDomainEvents();

        logger.LogInformation("Created order {OrderId} for {Customer}", order.Id, order.CustomerName);
        return Map(order);
    }

    public async Task<OrderDto?> GetOrderAsync(Guid id, CancellationToken ct = default)
    {
        var order = await repository.GetByIdAsync(id, ct);
        return order is null ? null : Map(order);
    }

    public async Task MarkProcessedAsync(Guid id, CancellationToken ct = default)
    {
        var order = await repository.GetByIdAsync(id, ct)
            ?? throw new InvalidOperationException($"Order {id} not found.");
        order.MarkProcessed();
        await repository.UpdateAsync(order, ct);
        logger.LogInformation("Marked order {OrderId} processed", id);
    }

    private static OrderDto Map(Order o) => new(o.