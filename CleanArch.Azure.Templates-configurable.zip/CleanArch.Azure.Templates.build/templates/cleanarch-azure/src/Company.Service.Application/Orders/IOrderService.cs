using Company.Service.Application.Common.Models;

namespace Company.Service.Application.Orders;

public interface IOrderService
{
    Task<OrderDto> CreateOrderAsync(CreateOrderRequest request, CancellationToken ct = default);
    Task<OrderDto?> GetOrderAsync(Guid id, CancellationToken ct = default);
    Task MarkProcessedAsync(Guid id, CancellationToken ct = default);
}
