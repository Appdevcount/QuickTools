using Azure.Storage.Blobs;
using Company.Service.Application.Common.Interfaces;

namespace Company.Service.Infrastructure.Storage;

internal sealed class BlobStorageService(BlobServiceClient client) : IBlobStorageService
{
    public async Task<Uri> UploadAsync(string container, string blobName, Stream content, CancellationToken ct = default)
    {
        var containerClient = client.GetBlobContainerClient(container);
        await containerClient.CreateIfNotExistsAsync(cancellationToken: ct);
        var blob = containerClient.GetBlobClient(blobName);
        await blob.UploadAsync(content, overwrite: true, ct);
        return blob.Uri;
    }

    public async Task<Stream?> DownloadAsync(string container, string blobName, CancellationToken ct = default)
    {
        var blob = client.GetBlobContainerClient(container).GetBlobClient(blobName);
        if (!await blob.ExistsAsync(ct)) return null;
        var response = await blob.DownloadStreamingAsync(cancellationToken: ct);
        return response.Value.Content;
    }
}
