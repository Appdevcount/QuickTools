#if (UseKeyVault)
using Azure.Identity;
using Microsoft.Extensions.Configuration;
#endif
using Microsoft.Extensions.Hosting;

namespace Company.Service.Infrastructure.Configuration;

public static class KeyVaultConfigurationExtensions
{
    /// <summary>
    /// Adds Azure Key Vault as a configuration source when "Azure:KeyVault:Uri" is set.
    /// Secrets named like "Azure--ServiceBus--QueueName" map onto config keys
    /// "Azure:ServiceBus:QueueName". Uses Managed Identity in Azure, az login locally.
    /// </summary>
    public static IHostApplicationBuilder AddAzureKeyVault(this IHostApplicationBuilder builder)
    {
#if (UseKeyVault)
        var vaultUri = builder.Configuration["Azure:KeyVault:Uri"];
        if (!string.IsNullOrWhiteSpace(vaultUri))
        {
            builder.Configuration.AddAzureKeyVault(new Uri(vaultUri), new DefaultAzureCredential());
        }
#endif
        return builder;
    }
}
