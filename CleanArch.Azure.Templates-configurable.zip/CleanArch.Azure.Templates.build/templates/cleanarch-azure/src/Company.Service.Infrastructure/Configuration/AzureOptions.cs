namespace Company.Service.Infrastructure.Configuration;

/// <summary>Strongly-typed Azure settings bound from configuration ("Azure" section).</summary>
public sealed class AzureOptions
{
    public const string SectionName = "Azure";

    public CosmosOptions Cosmos { get; init; } = new();
    public ServiceBusOptions ServiceBus { get; init; } = new();
    public BlobStorageOptions BlobStorage { get; init; } = new();
}

public sealed class CosmosOptions
{
    public string AccountEndpoint { get; init; } = string.Empty;
    public string Database { get; init; } = "appdb";
    public string Container { get; init; } = "orders";
}

public sealed class ServiceBusOptions
{
    public string FullyQualifiedNamespace { get; init; } = string.Empty;
    public string QueueName { get; init; } = "orders";
}

public sealed class BlobStorageOptions
{
    public string ServiceUri { get; init; } = string.Empty;
}
