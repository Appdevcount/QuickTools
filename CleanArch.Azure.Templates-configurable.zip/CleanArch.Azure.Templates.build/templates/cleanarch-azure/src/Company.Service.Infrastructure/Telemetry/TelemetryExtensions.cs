#if (UseTelemetry)
using Azure.Monitor.OpenTelemetry.AspNetCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
#endif

namespace Company.Service.Infrastructure.Telemetry;

public static class TelemetryExtensions
{
    /// <summary>
    /// Wires OpenTelemetry traces, metrics and logs to Azure Monitor / Application Insights.
    /// Reads the connection string from "ApplicationInsights:ConnectionString"
    /// (typically supplied via Key Vault or App Configuration). No-op if not configured.
    /// </summary>
    public static IServiceCollection AddAppTelemetry(this IServiceCollection services, IConfiguration config)
    {
#if (UseTelemetry)
        var connectionString = config["ApplicationInsights:ConnectionString"];
        if (!string.IsNullOrWhiteSpace(connectionString))
        {
            services.AddOpenTelemetry()
                .UseAzureMonitor(o => o.ConnectionString = connectionString);
        }
#endif
        return services;
    }
}
