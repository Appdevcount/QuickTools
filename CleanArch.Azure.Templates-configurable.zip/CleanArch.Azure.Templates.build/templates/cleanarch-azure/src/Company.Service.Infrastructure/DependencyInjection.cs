using Azure.Identity;
using Company.Service.Application.Common.Interfaces;
using Company.Service.Infrastructure.Configuration;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Options;
#if (UseCosmos)
using Company.Service.Infrastructure.Persistence;
using Microsoft.Azure.Cosmos;
#endif
#if (UseServiceBus)
using Azure.Messaging.ServiceBus;
using Company.Service.Infrastructure.Messaging;
#endif
#if (UseBlobStorage)
using Azure.Storage.Blobs;
using Company.Service.Infrastructure.Storage;
#endif

namespace Company.Service.Infrastructure;

public static class DependencyInjection
{
    /// <summary>
    /// Registers Azure-backed implementations of the Application ports.
    /// DefaultAzureCredential is used everywhere so the same code runs locally
    /// (az login / Visual Studio) and in Azure (Managed Identity) with no secrets.
    /// </summary>
    public static IServiceCollection AddInfrastructure(this IServiceCollection services, IConfiguration config)
    {
        services.Configure<AzureOptions>(config.GetSection(AzureOptions.SectionName));

        var credential = new DefaultAzureCredential();

#if (UseCosmos)
        services.AddSingleton(sp =>
        {
            var o = sp.GetRequiredService<IOptions<AzureOptions>>().Value.Cosmos;
            return new CosmosClient(o.AccountEndpoint, credential, new CosmosClientOptions
            {
                SerializerOptions = new CosmosSerializationOptions
                {
                    PropertyNamingPolicy = CosmosPropertyNamingPolicy.CamelCase
                }
            });
        });
        services.AddScoped<IOrderRepository, CosmosOrderRepository>();
#endif

#if (UseServiceBus)
        services.AddSingleton(sp =>
        {
            var o = sp.GetRequiredService<IOptions<AzureOptions>>().Value.ServiceBus;
            return new ServiceBusClient(o.FullyQualifiedNamespace, credential);
        });
        services.AddSingleton<IMessagePublisher, ServiceBusMessagePublisher>();
#endif

#if (UseBlobStorage)
        services.AddSingleton(sp =>
        {
            var o = sp.GetRequiredService<IOptions<AzureOptions>>().Value.BlobStorage;
            return new BlobServiceClient(new Uri(o.ServiceUri), credential);
        });
        services.AddSingleton<IBlobStorageService, BlobStorageService>();
#endif

        return services;
    }
}
