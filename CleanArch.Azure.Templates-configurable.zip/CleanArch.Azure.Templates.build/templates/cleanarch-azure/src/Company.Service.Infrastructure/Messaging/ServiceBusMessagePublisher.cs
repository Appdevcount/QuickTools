using System.Text.Json;
using Azure.Messaging.ServiceBus;
using Company.Service.Application.Common.Interfaces;
using Company.Service.Infrastructure.Configuration;
using Microsoft.Extensions.Options;

namespace Company.Service.Infrastructure.Messaging;

internal sealed class ServiceBusMessagePublisher(
    ServiceBusClient client,
    IOptions<AzureOptions> options) : IMessagePublisher
{
    private readonly ServiceBusSender _sender = client.CreateSender(options.Value.ServiceBus.QueueName);

    public async Task PublishAsync<T>(T message, CancellationToken ct = default) where T : class
    {
        var body = JsonSerializer.Serialize(message);
        var sbMessage = new ServiceBusMessage(body)
        {
            ContentType = "application/json",
            Subject = typeof(T).Name
        };
        await _sender.SendMessageAsync(sbMessage, ct);
    }
}
