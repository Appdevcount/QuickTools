using Company.Service.Application.Common.Interfaces;
using Company.Service.Domain.Entities;
using Company.Service.Infrastructure.Configuration;
using Microsoft.Azure.Cosmos;
using Microsoft.Extensions.Options;

namespace Company.Service.Infrastructure.Persistence;

internal sealed class CosmosOrderRepository : IOrderRepository
{
    private readonly Container _container;

    public CosmosOrderRepository(CosmosClient client, IOptions<AzureOptions> options)
    {
        var o = options.Value.Cosmos;
        _container = client.GetContainer(o.Database, o.Container);
    }

    public async Task<Order?> GetByIdAsync(Guid id, CancellationToken ct = default)
    {
        try
        {
            var response = await _container.ReadItemAsync<Order>(
                id.ToString(), new PartitionKey(id.ToString()), cancellationToken: ct);
            return response.Resource;
        }
        catch (CosmosException ex) when (ex.StatusCode == System.Net.HttpStatusCode.NotFound)
        {
            return null;
        }
    }

    public Task AddAsync(Order order, CancellationToken ct = default) =>
        _container.CreateItemAsync(order, new PartitionKey(order.Id.ToString()), cancellationToken: ct);

    public Task UpdateAsync(Order order, CancellationToken ct = default) =>
        _container.UpsertItemAsync(order, new PartitionKey(order.Id.ToString()), cancellationToken: ct);
}
