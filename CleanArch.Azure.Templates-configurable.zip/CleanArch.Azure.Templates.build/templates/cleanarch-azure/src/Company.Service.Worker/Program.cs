using Company.Service.Application;
using Company.Service.Infrastructure;
using Company.Service.Infrastructure.Configuration;
using Company.Service.Infrastructure.Telemetry;
#if (UseServiceBus)
using Company.Service.Worker.Workers;
#endif

var builder = Host.CreateApplicationBuilder(args);

// Same composition root as the Api: Key Vault, telemetry, then the layers.
builder.AddAzureKeyVault();
builder.Services.AddAppTelemetry(builder.Configuration);
builder.Services.AddApplication();
builder.Services.AddInfrastructure(builder.Configuration);

#if (UseServiceBus)
builder.Services.AddHostedService<OrderMessageConsumer>();
#endif

var host = builder.Build();
host.Run();
