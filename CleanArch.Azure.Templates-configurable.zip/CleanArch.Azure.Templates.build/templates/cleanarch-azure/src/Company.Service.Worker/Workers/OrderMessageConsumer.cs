using System.Text.Json;
using Azure.Messaging.ServiceBus;
using Company.Service.Application.Orders;
using Company.Service.Domain.Events;
using Company.Service.Infrastructure.Configuration;
using Microsoft.Extensions.Options;

namespace Company.Service.Worker.Workers;

/// <summary>
/// Background consumer for the orders queue. Uses ServiceBusProcessor for
/// automatic concurrency, prefetch and lock renewal. Each message is handled
/// in its own DI scope so scoped services (repositories) resolve correctly.
/// </summary>
public sealed class OrderMessageConsumer : BackgroundService
{
    private readonly ServiceBusProcessor _processor;
    private readonly IServiceProvider _services;
    private readonly ILogger<OrderMessageConsumer> _logger;

    public OrderMessageConsumer(
        ServiceBusClient client,
        IServiceProvider services,
        IOptions<AzureOptions> options,
        ILogger<OrderMessageConsumer> logger)
    {
        _services = services;
        _logger = logger;
        _processor = client.CreateProcessor(
            options.Value.ServiceBus.QueueName,
            new ServiceBusProcessorOptions { MaxConcurrentCalls = 5, AutoCompleteMessages = false });
        _processor.ProcessMessageAsync += OnMessageAsync;
        _processor.ProcessErrorAsync += OnErrorAsync;
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        _logger.LogInformation("Starting Service Bus processor...");
        await _processor.StartProcessingAsync(stoppingToken);
    }

    private async Task OnMessageAsync(ProcessMessageEventArgs args)
    {
        try
        {
            var evt = JsonSerializer.Deserialize<OrderCreatedEvent>(args.Message.Body.ToString());
            if (evt is not null)
            {
                await using var scope = _services.CreateAsyncScope();
                var orders = scope.ServiceProvider.GetRequiredService<IOrderService>();
                await orders.MarkProcessedAsync(evt.OrderId, args.CancellationToken);
                _logger.LogInformation("Processed OrderCreated for {OrderId}", evt.OrderId);
            }
            await args.CompleteMessageAsync(args.Message);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to process message {MessageId}", args.Message.MessageId);
            await args.AbandonMessageAsync(args.Message);
        }
    }

    private Task OnErrorAsync(ProcessErrorEventArgs args)
    {
        _logger.LogError(args.Exception, "Service Bus error in {Source}", args.ErrorSource);
        return Task.CompletedTask;
    }

    public override async Task StopAsync(CancellationToken cancellationToken)
    {
        await _processor.StopProcessingAsync(cancellationToken);
        await _processor.DisposeAsync();
        await base.StopAsync(cancellationToken);
    }
}
