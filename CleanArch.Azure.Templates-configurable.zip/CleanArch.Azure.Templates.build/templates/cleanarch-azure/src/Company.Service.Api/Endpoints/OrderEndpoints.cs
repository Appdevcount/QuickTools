using Company.Service.Application.Common.Models;
using Company.Service.Application.Orders;

namespace Company.Service.Api.Endpoints;

public static class OrderEndpoints
{
    public static IEndpointRouteBuilder MapOrderEndpoints(this IEndpointRouteBuilder app)
    {
        var group = app.MapGroup("/orders").WithTags("Orders");

        group.MapPost("/", async (CreateOrderRequest request, IOrderService service, CancellationToken ct) =>
        {
            var order = await service.CreateOrderAsync(request, ct);
            return Results.Created($"/orders/{order.Id}", order);
        });

        group.MapGet("/{id:guid}", async (Guid id, IOrderService service, CancellationToken ct) =>
        {
            var order = await service.GetOrderAsync(id, ct);
            return order is null ? Results.NotFound() : Results.Ok(order);
        });

        return app;
    }
}
