using Company.Service.Api.Endpoints;
using Company.Service.Application;
using Company.Service.Infrastructure;
using Company.Service.Infrastructure.Configuration;
using Company.Service.Infrastructure.Telemetry;

var builder = WebApplication.CreateBuilder(args);

// 1. Configuration sources (Key Vault layered on top when configured).
builder.AddAzureKeyVault();

// 2. Cross-cutting + layers.
builder.Services.AddAppTelemetry(builder.Configuration);
builder.Services.AddApplication();
builder.Services.AddInfrastructure(builder.Configuration);

// 3. API surface.
builder.Services.AddOpenApi();
builder.Services.AddEndpointsApiExplorer();

var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.MapOpenApi();
}

app.UseHttpsRedirection();
app.MapOrderEndpoints();
app.MapGet("/health", () => Results.Ok("Healthy"));

app.Run();
