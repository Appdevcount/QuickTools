# Company.Service

Generated from the **cleanarch-azure** template. API + background Worker in Clean Architecture, wired for Azure.

## Layers (dependencies point inward)

```
Api ─┐
     ├─► Infrastructure ─► Application ─► Domain
Worker ┘
```

| Project | Responsibility | May reference |
|---|---|---|
| `*.Domain` | Entities, value objects, domain events. Pure C#. | nothing |
| `*.Application` | Use-cases, ports (interfaces), DTOs. | Domain |
| `*.Infrastructure` | Azure SDK implementations of the ports. | Application, Domain |
| `*.Api` | HTTP host + endpoints. Composition root. | Application, Infrastructure |
| `*.Worker` | Background host + Service Bus consumer. Composition root. | Application, Infrastructure |

## Azure integrations

Cosmos DB (persistence), Service Bus (messaging), Blob Storage (files), Key Vault (secrets/config), Application Insights via OpenTelemetry (telemetry). All authenticate with `DefaultAzureCredential` — `az login` locally, Managed Identity in Azure. No connection strings in source.

## Run locally

```bash
dotnet restore
dotnet run --project src/Company.Service.Api
dotnet run --project src/Company.Service.Worker
```

Configure endpoints in each project's `appsettings.json` (or point `Azure:KeyVault:Uri` at a vault).
