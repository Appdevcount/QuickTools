using Company.Service.Domain.Entities;
using Xunit;

namespace Company.Service.UnitTests;

public class OrderTests
{
    [Fact]
    public void Create_WithValidInput_StartsPending()
    {
        var order = Order.Create("Acme Corp", 42.50m);

        Assert.Equal("Acme Corp", order.CustomerName);
        Assert.Equal(OrderStatus.Pending, order.Status);
        Assert.Single(order.DomainEvents);
    }

    [Theory]
    [InlineData("", 10)]
    [InlineData("Acme", 0)]
    [InlineData("Acme", -5)]
    public void Create_WithInvalidInput_Throws(string customer, decimal amount)
    {
        Assert.ThrowsAny<Exception>(() => Order.Create(customer, amount));
    }

    [Fact]
    public void MarkProcessed_SetsStatus()
    {
        var order = Order.Create("Acme Corp", 10m);
        order.MarkProcessed();
        Assert.Equal(OrderStatus.Processed, order.Status);
    }
}
