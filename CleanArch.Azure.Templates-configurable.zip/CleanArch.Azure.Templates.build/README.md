# YourCompany Clean Architecture Azure Templates

A `dotnet new` template pack that scaffolds a standardised service: an **API** and a **background Worker**, both in **Clean Architecture**, pre-wired for **Azure** (Cosmos DB, Service Bus, Blob Storage, Key Vault, Application Insights). It enforces the team naming convention `{Company}.{Service}.{Layer}`.

## Quick start

```bash
# Install the template from this folder
dotnet new install ./templates/cleanarch-azure

# Generate a new service (name = {Company}.{Service})
dotnet new cleanarch-azure -n Contoso.Orders -o Contoso.Orders

# Generated projects:
#   Contoso.Orders.Domain / .Application / .Infrastructure / .Api / .Worker
```

Turn features off when you don't need them:

```bash
dotnet new cleanarch-azure -n Contoso.Billing --UseBlobStorage false --UseServiceBus false
```

## What's in here

| Path | Purpose |
|---|---|
| `templates/cleanarch-azure/` | The template content (the solution that gets generated). |
| `templates/cleanarch-azure/.template.config/template.json` | Template manifest: name parameterization + Azure toggles. |
| `templatepack.csproj` | Packs everything into an installable NuGet package. |
| `docs/BUILD-GUIDE.md` | **Step-by-step manual walkthrough** — build this template from scratch, by hand. Use for the team demo. |

## Full walkthrough

See **[docs/BUILD-GUIDE.md](docs/BUILD-GUIDE.md)** — it explains every file, every command, and how to test, pack, publish and consume the template.

## Everything is configurable at creation time

Names, Azure endpoints, database/queue/container names, ports, the sample entity, and optional Tests/Docker/CI are all prompts — see **[docs/BUILD-GUIDE.md → Appendix 3](docs/BUILD-GUIDE.md)** for the full list. Example:

```bash
dotnet new cleanarch-azure -n Contoso.Billing -o Contoso.Billing \
  --EntityName Invoice --CosmosDatabase billing --ServiceBusQueue invoice-events \
  --UseBlobStorage false --IncludeDocker true --IncludeCI true --CIProvider azuredevops
```
